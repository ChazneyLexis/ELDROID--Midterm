package com.example.fernandez_midterm_requirement;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText movieID, movTitle, movYear, movRunTime, movieLanguage, movReleasedDate, movCountry;
    Button viewAll, searchID, deleteRecord, addMovie, clear, update;
    SQLiteDatabase movieDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        movieID = findViewById(R.id.movieid);
        movTitle = findViewById(R.id.movietitle);
        movYear = findViewById(R.id.movieyear);
        movRunTime = findViewById(R.id.movietime);
        movieLanguage = findViewById(R.id.movielang);
        movReleasedDate = findViewById(R.id.moviedate);
        movCountry = findViewById(R.id.moviecountry);

        viewAll = findViewById(R.id.viewallbutton);
        searchID = findViewById(R.id.searchbutton);
        deleteRecord = findViewById(R.id.deletebutton);
        addMovie = findViewById(R.id.addbutton);
        clear = findViewById(R.id.clearbutton);
        update = findViewById(R.id.updatebutton);

        viewAll.setOnClickListener(this);
        searchID.setOnClickListener(this);
        deleteRecord.setOnClickListener(this);
        addMovie.setOnClickListener(this);
        clear.setOnClickListener(this);
        update.setOnClickListener(this);

        movieDB = openOrCreateDatabase("Movie_Database", Context.MODE_PRIVATE, null);

        movieDB.execSQL("CREATE TABLE IF NOT EXISTS Movie_Database(movieID VARCHAR PRIMARY KEY NOT NULL, movTitle VARCHAR NOT NULL, movYear INT NOT NULL, movRunTime INT NOT NULL, movieLanguage VARCHAR NOT NULL, movReleasedDate DATE NOT NULL, movCountry VARCHAR NOT NULL)");

        movieID.requestFocus();

    }

    public void showMessage(String title, String message) {
        Builder builder = new Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText() {
        movieID = (findViewById(R.id.movieid));
        movieID.getText().clear();
        movTitle = (findViewById(R.id.movietitle));
        movTitle.getText().clear();
        movYear = (findViewById(R.id.movieyear));
        movYear.getText().clear();
        movRunTime = (findViewById(R.id.movietime));
        movRunTime.getText().clear();
        movieLanguage = (findViewById(R.id.movielang));
        movieLanguage.getText().clear();
        movReleasedDate = (findViewById(R.id.moviedate));
        movReleasedDate.getText().clear();
        movCountry = (findViewById(R.id.moviecountry));
        movCountry.getText().clear();
    }


    @Override
    public void onClick(View v) {
        if (v == addMovie) {
            Cursor c = movieDB.rawQuery("Select * FROM Movie_Database WHERE movieID= '" + movieID.getText() + "'", null);
            movieID.setError(null);
            if (TextUtils.isEmpty(movieID.getText().toString())) {
                movieID.setError("Movie ID is required!");
                movieID.requestFocus();
            }
            else if(c.moveToFirst()) {
                movieID.setError("Movie ID is duplicate!");
                movieID.requestFocus();
            }
            else {
                movieDB.execSQL("INSERT INTO Movie_Database VALUES('" + movieID.getText() + "','" + movTitle.getText() + "','" + movYear.getText() + "','" + movRunTime.getText() + "','" + movieLanguage.getText() + "','" + movReleasedDate.getText() + "','" + movCountry.getText() + "');");
                showMessage("Success", "Record Added.");
                movieID.setError(null);
                clearText();
            }
        } else if (v == deleteRecord) {
            Cursor c = movieDB.rawQuery("Select * FROM Movie_Database WHERE movieID= '" + movieID.getText() + "'", null);
            movieID.setError(null);
            if (TextUtils.isEmpty(movieID.getText().toString())) {
                movieID.setError("Movie ID is required!");
                movieID.requestFocus();
            }
            else if (c.getCount() == 0) {
                showMessage("ERROR", "No Movie ID found.");
            }
            else if (c.moveToFirst()) {
                movieDB.execSQL("DELETE FROM Movie_Database WHERE movieID= '" + movieID.getText() + "'");
                showMessage("Success", "Record Deleted.");
                movieID.setError(null);

            }
            clearText();
        } else if (v == searchID) {
            Cursor c = movieDB.rawQuery("SELECT * FROM Movie_Database WHERE movieID = '" + movieID.getText() + "'", null);
            if (c.getCount() == 0) {
                showMessage("ERROR", "No movie ID found.");
            }
            StringBuffer buffer = new StringBuffer();
            if (c.moveToNext())
            {
                buffer.append("Movie ID: " + c.getString(0) + "\n");
                buffer.append("Movie Title: " + c.getString(1) + "\n");
                buffer.append("Year: " + c.getString(2) + "\n");
                buffer.append("Running Time(mins): " + c.getString(3) + "\n");
                buffer.append("Language: " + c.getString(4) + "\n");
                buffer.append("Released Date: " + c.getString(5) + "\n");
                buffer.append("Country: " + c.getString(6) + "\n");
                showMessage("Movie Details", buffer.toString());
            }
        } else if (v == viewAll) {
            Cursor res = movieDB.rawQuery("SELECT * FROM Movie_Database", null);
            StringBuffer buffer = new StringBuffer();
            while (res.moveToNext())
            {
                buffer.append("Movie ID: " + res.getString(0) + "\n");
                buffer.append("Movie Title: " + res.getString(1) + "\n");
                buffer.append("Year: " + res.getString(2) + "\n");
                buffer.append("Running Time(mins): " + res.getString(3) + "\n");
                buffer.append("Language: " + res.getString(4) + "\n");
                buffer.append("Released Date: " + res.getString(5) + "\n");
                buffer.append("Country: " + res.getString(6) + "\n\n");
            }
            if (res.getCount() == 0) {
                showMessage("ERROR", "No records found.");
            }
            else
                showMessage("Movie Details", buffer.toString());
        } else if (v == clear){

            movieID = (findViewById(R.id.movieid));
            movieID.getText().clear();
            movTitle = (findViewById(R.id.movietitle));
            movTitle.getText().clear();
            movYear = (findViewById(R.id.movieyear));
            movYear.getText().clear();
            movRunTime = (findViewById(R.id.movietime));
            movRunTime.getText().clear();
            movieLanguage = (findViewById(R.id.movielang));
            movieLanguage.getText().clear();
            movReleasedDate = (findViewById(R.id.moviedate));
            movReleasedDate.getText().clear();
            movCountry = (findViewById(R.id.moviecountry));
            movCountry.getText().clear();
        } else if (v == update) {
            Cursor c = movieDB.rawQuery("SELECT * FROM Movie_Database WHERE movieID = '" + movieID.getText() + "'", null);
            if(c.getCount()==0){
                showMessage("ERROR", "Record not found!");
            }
            else {
                movieDB.execSQL("UPDATE Movie_Database SET movRuntime=" + movRunTime.getText().toString() + " WHERE movieID= '" + movieID.getText() + "'");
                showMessage("SUCCESS", "Records Updated");
            }
        }
    }
}